<?php
session_start();
if (!isset($_SESSION['users'])){
    Location:"profile.php";
}
$email= $_SESSION['users'];
$url="chat.php?username=".$email;



?>

<html lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="profile.css">
  <title>Profile</title>
  <script type="text/javascript">
    function updatepicture(pic){
      document.getElementById("image").setAttribute("src",pic);
    }
  </script>
</head>
<body>
  <!--bgcolor="https://i.pinimg.com/originals/32/b8/77/32b877ed4aa7778cc7d43ebb7d95a6f1.png"-->
<div class="a">
      <label>
  <h1 align="center"> Welcome to Welcomebook</h1>
      </label>
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>

</div><br>

<div class="upload">


<h1>Note: Account under maintenance. Please logout for now.</h1>
<img style="min-height: 200px; min-width: 50%; max-height: 200px" id="image"><br>
<iframe style="display:none;" name="iframe" ></iframe>

<p id="message"> Select file to uploaded.</p>

<form id="form" method="post" action="upload.php" enctype="multipart/form-data" target="iframe">
      <input type="file" name="file" id="file"/>
      <input type="submit" name="submit" id="submit" value="Upload File"/>
</form>
<br>
</div>

<div class="info">
  <hr>
  <h2 align="center"> Your Profile Information</h2>
<hr>
<label class="in">
    <?php
    $mysqli= mysqli_connect("localhost",'username','password', 'dbname'); #connection of database
	

	
    $resultSet = mysqli_query($mysqli,"SELECT * FROM accounts WHERE email = '$email' LIMIT 1");

    if($resultSet->num_rows !=0){
      //Process login
      $row = $resultSet->fetch_assoc();
      $name = $row['username'];
      $email = $row['email'];
      $vkey=$row['vkey'];
      $date = $row['createdate'];
      $date = strtotime($date);
      $date = date('M d Y', $date);
    }
      else{
      echo "error";}
      ?>
  <p>

      Name     :<?=$name?><br>
      Email    :<?=$email?><br>
      Key    :<?=$vkey?><br>
      Created date    :<?=$date?><br>
      Password : <?=$_SESSION['passs']?><br>
     Address  :<br>
      Other    :<br>
      </p>
</label>
<br>

<div class="footer">
  <h2 align="center"> &copy; Welcomebook</h2>
</div>

</div>
</body>
</html>
