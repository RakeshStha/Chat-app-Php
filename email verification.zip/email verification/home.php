<html lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="profile.css">
  <title>Home</title>
  <script type="text/javascript">
    function updatepicture(pic){
      document.getElementById("image").setAttribute("src",pic);
    }
  </script>
</head>
<body>
  <!--bgcolor="https://i.pinimg.com/originals/32/b8/77/32b877ed4aa7778cc7d43ebb7d95a6f1.png"-->
<div class="a">
      <label>
  <h1 align="center"> Welcome to Welcomebook</h1>
      </label>
      <ul>
        <li><a href="video.html">Home</a></li>
        <li><a href="chat.php">Chat</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>

</div>

<div class="home-a">
<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>

<p class="home">!!!!!Account Under maintenance!!!!!</p>

<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>
<br><br><br>


<div class="footer">
  <h2 align="center"> &copy; Welcomebook | Developed by <a href="https://unknownbeginner.000webhostapp.com/">Rakesh Shrestha</a></h2>
</div>
</div>

</body>
</html>
