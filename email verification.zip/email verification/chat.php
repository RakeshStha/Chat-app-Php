<?php

session_start();
if (!isset($_SESSION['users'])){
    Location:"home.php";
}
$email= $_SESSION['users'];
$url="chat.php?username=".$email;



//Database Connection
$con=mysqli_connect('localhost','username','password');
    if(!$con)
{
    echo 'Not Connected To Server';
}
if(!mysqli_select_db($con,'dbname'))
{
    echo 'Database Not Selected';
}
?>


<html lang="en">
<head>
  <link rel="stylesheet" type="text/css" href="profile.css">
  <title>Chat</title>
<style>
	#main{border:1px solid black; width:450px; height: 100%; margin: 24px auto;}
	#message_area{width:98%; border:1px solid blue; height:400px;}
</style>

<script src="http://code.jquery.com/jquery-latest.js"></script>
<script>
    $(document).ready(function(){
		 $("#div_refresh").load("chatdata.php");
        setInterval(function() {
            $("#div_refresh").load("chatdata.php");
        }, 1000);
    });
 
</script>
</head>
<body>


  <!--bgcolor="https://i.pinimg.com/originals/32/b8/77/32b877ed4aa7778cc7d43ebb7d95a6f1.png"-->
<div class="a">
      <label>
  <h1 align="center"> Welcome to Welcomebook</h1>
      </label>
      <ul>
        <li><a href="home.php">Home</a></li>
        <li><a href="#">Chat</a></li>
        <li><a href="profile.php">Profile</a></li>
        <li><a href="logout.php">Logout</a></li>
      </ul>

</div>

    <h1 align='center';>Note: Please don't use cuss word. Thank You</h1><hr>

  <?php
  if(isset($_POST['submit'])){

      $message=$_POST['message'];
      $email= $_SESSION['users'];

      $sql="INSERT INTO chat (message,username) VALUES('$message','$email')";

    if(mysqli_query($con, $sql)){

        }
      }

      ?>
<div id="div_refresh">
        <?php
include("chatdata.php");

        ?>
</div>

<div class="main">


<form method="post">



	<br>
	<input type="text" name="message" style="width: 400px; height:40px;" placeholder="Type you message" required/>


	<input type="submit" name="submit" style="height:30px; width: 200px;" value="Send"/>


	</form>
</div>


<div class="footer">
  <h2 align="center"> &copy; Welcomebook | Developed by <a href="https://www.shrestharakesh.com.np/">Rakesh Shrestha</a></h2>
</div>
</div>

</body>
</html>
