<?php
session_start();?>
<div>
 <h1 align="center"> Thank You For your Registration.</h1><hr>
<pre>
 <h2>Your personal detail are:</h2>

 Username      :  <span><?=$_SESSION['user']?></span>

 Email Address :  <span><?=$_SESSION['email']?></span>

 Gender         :  <span><?=$_SESSION['gen']?></span>

 Date Of Birth  :  <span><?=$_SESSION['date']?></span>

 Current Password:  <span><?=$_SESSION['pass']?></span><h3>Securing......</h3>

                  <input type="submit" value="Exit" onclick="window.location.href='index.php';" onclick="return mess();">
</pre>
<script type="test/javascript">
        alert("Thank you for registration");
        return true;
    }
</script>
 <h3>Note: Please use your email as username and password as current password to login. Thank You!</h3>
 <h4>Remember your password.</h4>
</div>
<div>
 <?php
 $mysqli=mysqli_connect('localhost','username','password','dbname');
 $sql='SELECT username, email,gender,dob FROM user_account';
   $result = mysqli_query($GLOBALS['mysqli'], $sql); //$request=mysqli_result object
 ?>
 <hr>
   <h2><u>All registered accounts are:</u></h2>
 <?php
 while($row= $result->fetch_assoc()){
   echo'<pre>';
   echo "<div><span>Name          : $row[username]</span></br>";
   echo "<div><span>Email address : $row[email]</span></br>";
   echo "<div><span>Gender        : $row[gender]</span></br>";
   echo "<div><span>Date of Birth : $row[dob]</span></br>";
   echo'</pre>';
   #echo "<a href='https://unknownbeginner.000webhostapp.com/'> &copy; Developed by Rakesh Shrestha</a>";

 }
 exit;
 ?>

 </div
