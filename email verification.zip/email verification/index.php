<?php
$error=NULL;

session_start();
$_session['message']='';
if(isset($_POST['submit'])){

	//Connect to the database
    $mysqli= mysqli_connect("localhost",'username','password',"dbname");
    //end

	$email=$_POST['user'];
	$password=$_POST['pass'];
	$password= md5($password);

	$sql ="SELECT * FROM accounts WHERE email = '$email' AND password = '$password' LIMIT 1";
        
    $resultSet = mysqli_query($GLOBALS['mysqli'],$sql);

    if($resultSet->num_rows !=0){
    //Process login
      $row = $resultSet->fetch_assoc();
      $verified = $row['verified'];
      $email = $row['email'];
      $date = $row['createdate'];
      $date = strtotime($date);
      $date = date('M d Y', $date);
	
	if($verified == 1){  
	    
	   
	        $username=$_POST['user'];
	        $_SESSION['users']= $email;
	        header("Location:profile.php");
	    
	         $_SESSION['passs']= $password;
		        header("Location:profile.php");
	}
	else{
	    $error = "This account has not yet been verified. An email was sent to $email on $date";
	}
	}
	else{

		 $error = "The username or password you entered is incorrect";


	}
	mysqli_close($mysqli);
}
 ?>

 <html>
<head>
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="login.css">
    <style type="text/css">
    	body{
  background-image:url(https://encrypted-tbn0.gstatic.com/images?q=tbn%3AANd9GcT7QTCMUJkMuxeBAz5fes80JGV1kpsGFqxg8I6IB4MZbfW7_9J0&usqp=CAU);
  background-size: 100%;
}
#a{
  width: 500px;
  height: 70%;
  overflow: hidden;
  border: 2px solid 000;
  margin: 50px auto;
  padding: 10px;
}
#c{
  width: 100%;
  margin-bottom: 5px;
  padding: 8px 12px;
  border: 1px solid 000;
  box-sizing: border-box;
  border-radius: 3px;
}

#b {
  background-image:url(https://i.pinimg.com/originals/32/b8/77/32b877ed4aa7778cc7d43ebb7d95a6f1.png);
  width: 250px;
  height: 90%;
  margin: 10px auto;
  background-color: #fff;
  border: 2px solid 000;
  padding: 40px 50px;
}

.d{

    text-align: center;
  
}

.button {
  border-radius: 2px;
  background-color: #3897f0;
  border-color: #3897f0;
  text-align: center;
  font-size: 18px;
  padding: 5px;
  width: 100px;
  transition: all 0.5s;
  cursor: pointer;

}

.button span {
  cursor: pointer;
  display: inline-block;
  position: relative;
  transition: 0.5s;
}

.button span:after {

  content: #90EE90;
  position: absolute;
  opacity: 0;
  top: 0;

  transition: 0.5s;
}

.button:hover span {

  padding-right: 10px;
}

.button:hover span:after {

  opacity: 1;
  right: 0;
}
  </style>
</head>
<body>
<form action="" method="POST">

<div id="a">
<div id="b">
    <center>
    <?php
    echo $error;
    ?>
</center>
<h1 align="center"> Welcome to Welcomebook </h1>

 <label>Email:
 <input type="email" name="user" placeholder="xxx@email.com" id="c" required>
 </label><br><br>

 <label>Password:
 <input type="password" name="pass" placeholder="******" id="c" required>
 </label><br><br>

 <div class="d">
<input class="button" type="submit" name="submit" value="Login"/>
</div>
<br>

<label>
  Don't have an account?<a href="signup.php">Sign up</a>
</label>


</div>
</div>
</form>

 </body>
 </html>