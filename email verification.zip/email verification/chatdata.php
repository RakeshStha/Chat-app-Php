<?php

$con=mysqli_connect('localhost','username','password');
    if(!$con)
{
    echo 'Not Connected To Server';
}
if(!mysqli_select_db($con,'username'))
{
    echo 'Database Not Selected';
}



$sql='SELECT message, username FROM chat';
  $result=mysqli_query($GLOBALS['con'], $sql);

if($result->num_rows>0){
while($row= mysqli_fetch_array($result)){
    date_default_timezone_set('Asia/Kathmandu');
    echo '<pre>';
  echo ('<h2 style="color:black">'.$row['username'].'</h2>');   echo date('Y-m-d')."\n".date("h:i:s:a");
  echo '<h3 style="color:red">'.$row['message'].'</h3>'; 
  echo '</pre>';
  


  echo'<hr>';
    }
}
?>
